window.onload = function(){
	var di = null;
	var intro_show_len = qS("#intro_show_len")
	var introduce = qS("#introduce")
	introduce.addEventListener("keyup", function(){
		var len = introduce.value.length;
		if(len > 200){
			var str = introduce.value
			introduce.value = str.substring(0, 200)
			len = 200
		}
		intro_show_len.innerText = len + '/200'
	})
	var file = qS("#file")
	file.onchange = function(){
		var suffix = file.value.substring(file.value.lastIndexOf('.') + 1)
		if(suffix != 'jpg' && suffix != 'png' && suffix != 'bmp'){
			alert("請上傳圖片")
			return false
		}
		var fr = new FileReader()
		fr.onload = function(){
			di = fr.result
			document.getElementsByClassName("preview")[0].style["background-image"] = "url('"+di+"')"
		}
		fr.readAsDataURL(file.files[0])
	}
	qS("#location_button").addEventListener("click", function(){
//		var nav = new BMap.Geolocation()
//		nav.getCurrentPosition(function(r){
//			if(this.getStatus() == BMAP_STATUS_SUCCESS){
//				qS("#address").innerText = r.address.province + " " + r.address.city
//			}
//		})
		if(navigator.geolocation){
			qS("#address").innerText = "获取中";
			navigator.geolocation.getCurrentPosition(function(r){
				qS("#address").innerText = r.coords.latitude + " " + r.coords.longitude;
			}, function(error){
				switch(error.code) {
					case error.PERMISSION_DENIED:
						alert("您拒绝获取位置的请求");
						break;
					case error.POSITION_UNAVAILABLE:
						alert("位置不可用");
						break;
					case error.TIMEOUT:
						alert("请求超时");
						break;
					case error.UNKNOWN_ERROR:
						alert("未知错误");
						break;
				}
				qS("#address").innerText = "-";
			})
		}else{
			alert("您的浏览器不支持获得坐标")
		}
	})
	document.getElementsByClassName('submit')[0].addEventListener('click', function(){
		var shop_name = qS('#shop_name').value.trim();
		var shop_keeper = qS('#shop_keeper').value.trim();
		var introduce = qS('#introduce').value.trim();
		var address = qS('#address').innerText;
		var img_data = di;
		if(shop_name == "" || shop_name == null){
			alert("請填寫店名");
			return false;
		}
		var count = getItem("count");
		function setData(i){
			localStorage.setItem("count", i);
			localStorage.setItem("sn" + i, shop_name);
			localStorage.setItem("sk" + i, shop_keeper);
			localStorage.setItem("intr" + i, introduce);
			localStorage.setItem("addr" + i, address);
			localStorage.setItem("image" + i, img_data);
		}
		if(count == null){
			setData(0);
		}else{
			var i = parseInt(getItem("count"));
			++i;
			setData(i)
		}
		location.href="success.html"
	})
}