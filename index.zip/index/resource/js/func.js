function getItem(key){
	return localStorage.getItem(key)
}

function getShop(i){
	return getItem("count") == null || getItem("count") < i ? null : {
		addr: getItem("addr" + i),
		image: getItem("image" + i),
		sn: getItem("sn" + i),
		sk: getItem("sk" + i),
		intr: getItem("intr" + i)
	}
}

function getUrlValue(key){
	var href = location.href;
	if(href.indexOf('?') == -1)
		return null;
	var str = href.substring(href.indexOf('?') + 1).split('&');
	for(var s in str){
		if(str[s].substring(0, str[s].indexOf('=')) == key)
			return str[s].substring(str[s].indexOf('=') + 1)
	}
	return null;
}

function qS(s){
	return document.querySelector(s);
}

function qSA(s){
	return document.querySelectorAll(s);
}