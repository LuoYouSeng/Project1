var count = getItem("count");
if(count == null){
	var c = document.getElementById('container');
	c.style["display"] = "flex"
	c.style["justify-content"] = "center"
	document.write("<span class='norecord'>no record</span>")
}else{
	for(var i = 0;i <= count;i ++){
		var obj = getShop(i);
		document.write('<div class="list_item">\
					<div class="list_item_left">\
						<div class="list_item_shop_name">\
							<label>enterprise:</label>\
							<span>'+obj.sn+'</span>\
						</div>\
						<div class="list_item_shop_keeper">\
							<label>holder:</label>\
							<span>'+obj.sk+'</span>\
						</div>\
						<div class="list_item_introduce">\
							<span>'+obj.intr+'</span>\
						</div>\
						<div class="list_item_location"><a href="https://www.baidu.com/s?ie=UTF-8&wd='+obj.addr+'" target="_blank">location: '+obj.addr+'</a></div>\
						<a href="share/share_en.html?id='+i+'" class="share_button">share</a>\
					</div>\
					<div class="list_item_right">\
						<img class="list_item_image" src="'+obj.image+'" alt="圖片">\
					</div>\
				</div>')
	}
}