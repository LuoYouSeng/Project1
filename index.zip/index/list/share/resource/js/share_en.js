var id = getUrlValue("id");
let obj = null;
if(id > getItem("count") || id == null){
	document.write("<h1>don't have fun with website</h1>")
}else{
	obj = getShop(id);
	document.write('\
	<div class="container">\
	<div class="list_item">\
		<div class="list_item_left">\
			<div class="list_item_shop_name">\
				<label>enterprise:</label>\
				<span>'+obj.sn+'</span>\
			</div>\
			<div class="list_item_shop_keeper">\
				<label>holder:</label>\
				<span>'+obj.sk+'</span>\
			</div>\
			<div class="list_item_introduce">\
				<span>'+obj.intr+'</span>\
			</div>\
			<div class="list_item_location"><a href="https://www.baidu.com/s?ie=UTF-8&wd='+obj.addr+'" target="_blank">location: '+obj.addr+'</a></div>\
		</div>\
		<div class="list_item_right">\
			<img class="list_item_image" src="'+obj.image+'" alt="圖片">\
		</div>\
	</div>\
	</div>');
}